package com.example.invaders;

public class Score {

    private String name;
    private int score;
    private double lat;
    private double lon;

    // Default constructor
    public Score() { }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name with fluent interface
    public Score setName(String name) {
        this.name = name;
        return this;
    }

    // Getter for score
    public int getScore() {
        return score;
    }

    // Setter for score with fluent interface
    public Score setScore(int score) {
        this.score = score;
        return this;
    }

    // Getter for latitude
    public double getLat() {
        return lat;
    }

    // Setter for latitude with fluent interface
    public Score setLat(double lat) {
        this.lat = lat;
        return this;
    }

    // Getter for longitude
    public double getLon() {
        return lon;
    }

    // Setter for longitude with fluent interface
    public Score setLon(double lon) {
        this.lon = lon;
        return this;
    }
}
