package com.example.invaders;

public interface OnMain {
    void runOnMainThread(Runnable r);
}
