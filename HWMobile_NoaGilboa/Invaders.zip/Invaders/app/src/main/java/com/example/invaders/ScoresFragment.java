package com.example.invaders;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;

import java.util.ArrayList;

public class ScoresFragment extends Fragment {

    private AppCompatActivity activity;
    private MaterialButton[] top;
    private ArrayList<Score> scores;

    public ScoresFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_fragment_scores, container, false);
        findViews(view);
        addPlayer();
        return view;
    }

    public void setActivity(AppCompatActivity activity) {
        this.activity = activity;
    }

    private void findViews(View view) {
        top = new MaterialButton[]{
                view.findViewById(R.id.score_1),
                view.findViewById(R.id.score_2),
                view.findViewById(R.id.score_3),
                view.findViewById(R.id.score_4),
                view.findViewById(R.id.score_5),
                view.findViewById(R.id.score_6),
                view.findViewById(R.id.score_7),
                view.findViewById(R.id.score_8),
                view.findViewById(R.id.score_9),
                view.findViewById(R.id.score_10)
        };
    }

    private void addPlayer() {
        String js = MSPV3.getMe().getString("MY_DB", "");
        MyDB DB= new Gson().fromJson(js, MyDB.class);
        scores = DB.getRecords();

        int limit = Math.min(scores.size(), 10); // Limit to 10 scores if available

        for (int i = 0; i < limit; i++) {
            Score score = scores.get(i);
            top[i].setText("Name: " + score.getName() + " Score: " + score.getScore());
            double lat = score.getLat();
            double lon = score.getLon();
            top[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((Top10) activity).zoomMap(lon, lat);
                }
            });
        }
    }
}
