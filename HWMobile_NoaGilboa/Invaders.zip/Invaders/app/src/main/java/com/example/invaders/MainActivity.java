package com.example.invaders;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements OnMain {
    private Game game;


    @Override
    public void runOnMainThread(Runnable r) {
        runOnUiThread(r);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        game = new Game(this);

        FloatingActionButton moveLeftBtn = findViewById(R.id.moveLeftBtn);
        FloatingActionButton moveRightBtn = findViewById(R.id.moveRightBtn);

        moveLeftBtn.setOnClickListener((v) -> {
            game.movePlayerLeft();
        });

        moveRightBtn.setOnClickListener((v) -> {
            game.movePlayerRight();
        });


    }


}