package com.example.invaders;


import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.google.android.material.button.MaterialButton;

public class Menu_Game extends AppCompatActivity {
    private MaterialButton menu_BTN_button;
    private MaterialButton menu_BTN_sensor;
    private MaterialButton menu_BTN_highScores;
    private AppCompatImageView menu_IMG_background;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_game);
        GameUtils.hideSystemUI(this);
        findView();

        clicked();

    }

    private void clicked() {
        menu_BTN_button.setOnClickListener(view -> moveToGame(false));
        menu_BTN_sensor.setOnClickListener(view -> moveToGame(true));
        menu_BTN_highScores.setOnClickListener(view -> moveToScores());
    }

    private void findView() {
        menu_BTN_button = findViewById(R.id.menu_BTN_button);
        menu_BTN_sensor = findViewById(R.id.menu_BTN_sensor);
        menu_BTN_highScores = findViewById(R.id.menu_BTN_highScores);
        menu_IMG_background = findViewById(R.id.menu_IMG_background);

    }

    public void moveToGame(boolean sensorMode) {
        Intent gameIntent = new Intent(this, MainActivity.class);

        Bundle bundle = new Bundle();
        //bundle.putBoolean(Game.SENSOR_MODE, sensorMode);

        gameIntent.putExtras(bundle);
        startActivity(gameIntent);
    }

    public void moveToScores() {
        Intent ScoreIntent = new Intent(this,Top10.class);

        startActivity(ScoreIntent);
    }
}
