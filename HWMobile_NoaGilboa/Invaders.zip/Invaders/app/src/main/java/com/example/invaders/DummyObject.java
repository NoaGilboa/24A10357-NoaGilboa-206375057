package com.example.invaders;

import android.content.Context;
import android.widget.ImageView;

public class DummyObject extends GameObject {

    public DummyObject(Context context) {
        super(new ImageView(context));
    }
}
